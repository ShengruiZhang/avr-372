// Dale Hetherington
// January 23, 2019
// Assignment:  Classroom example program
//
// Description: main program to turn on LEDs
//----------------------------------------------------------------------


#include <avr/io.h>   // this includes all of the SFR macros
#include "led.h"

int main ()    {
    initLEDs();  // Initialize the LED

    while(1)    {

    }
        return(0);
}


// Dale Hetherington
// January 23, 2019
// Assignment:  Classroom example program
//
// Description: Header file
//----------------------------------------------------------------------


#ifndef LED_H
#define LED_H

void initLEDs();

#endif

#ifndef LED_H_
#define LED_H_

void init_LED_PA();
void LED_set_status(uchar led_status_bit);

#endif
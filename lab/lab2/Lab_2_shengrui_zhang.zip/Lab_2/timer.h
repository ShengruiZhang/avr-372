#ifndef TIMER_H_
#define TIMER_H_

void init_timer_8();
void init_timer_16();

#endif
/*
 * Header - ADC
 *
 * Created: 2020-04-02 03:14:38
 * Author: Shengrui Zhang
 */ 
#ifndef ADC_H_
#define ADC_H_

typedef unsigned int uint;

void init_ADC_0();
void ADC_Start();

#endif /* ADC_H_ */
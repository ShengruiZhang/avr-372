/*
 * Header - Button
 *
 * Created: 2020-05-06 17:46:07
 *
 * Author: Shengrui Zhang
			Zepeng Cai
 */ 
#ifndef _SWITCH_H_
#define _SWITCH_H_

void init_button_PB4();
void init_button_PD0();

#endif
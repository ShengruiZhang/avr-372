/*
 * Header - Pulse Width Modulation
 *
 * Created: 2020-05-01 18:04:04
 *
 * Author: Shengrui Zhang
			Zepeng Cai
 */ 
#ifndef _PWM_H
#define _PWM_H

void init_timer_3(enum TimerMode _mode_timer3);
void Timer_3_SetWidth(float _Width_timer3);

#endif